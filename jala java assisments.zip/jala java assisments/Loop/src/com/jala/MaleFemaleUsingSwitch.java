package com.jala;


//12. Print gender (Male/Female) program according to given M/F using switch

import java.util.Scanner;

public class MaleFemaleUsingSwitch {
    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter M/F : ");
        char gender=sc.next().charAt(0);
        switch (gender){
            case 'M':
                System.out.println("Male Gender");
                break;
            case 'F':
                System.out.println("Female Gender");
                break;
            default:
                System.out.println("No gender selected");
        }



    }
}
