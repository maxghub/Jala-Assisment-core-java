package com.jala;


//4. Create a class with PUBLIC fields and methods.
//        Access the public methods and fields from any class in the same package or different
//        Package.




//from same package
public class ChildAccessPublic {
    public int x = 1;

    public void m1() {
        System.out.println("public method");
    }

}
class ChildAcc{
    public static void main(String[] args) {
        ChildAccessPublic c=new ChildAccessPublic();
        c.m1();
        System.out.println(c.x);
    }
}
