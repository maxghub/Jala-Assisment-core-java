package com.jala.arrays;


//12. Write a method to remove duplicate elements from an array

public class RemoveDuplEle {
    static void removeDupl(int[] arr) {
        int count = 0;

        for (int i = 0; i < arr.length; i++) {
            int x=0;
            for (int j = i+1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                   x=1;
                   break;
                }
            }
            if(x==0){
                System.out.println(arr[i]);
            }
        }
    }

    public static void main(String[] args) {
        int[] arr={1,4,5,3,4,6};
        removeDupl(arr);
    }
}
