package com.java.constructorjava;


//    3. Apply private, public, protected and default access modifiers to the constructor


//    5. Try to call the constructor multiple times with the same object


public class PublicPrivateProtectedDefaulModifier {

    int id;
    String name;

    //public
  public PublicPrivateProtectedDefaulModifier(int id,String name){
      this("msdjkf");
        this.id=id;
        this.name=name;
        System.out.println("public constructor");
    }


    //private
  private PublicPrivateProtectedDefaulModifier(int id){
      this(1,"ajdhd");
        this.id=id;
        System.out.println("private constructor");
    }



    //protected
    protected PublicPrivateProtectedDefaulModifier(String name){
      this.name=name;
        System.out.println("protected constructor");
    }

    //Default
    PublicPrivateProtectedDefaulModifier(){
      this(11);
        System.out.println("Default constructor");
    }
    public static void main(String[] args) {

        //call the constructor multiple times with the same object
        PublicPrivateProtectedDefaulModifier p=new PublicPrivateProtectedDefaulModifier();

    }
}
