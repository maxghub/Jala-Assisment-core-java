package com.java.exceptionhandling;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


//12. Write a program to generate IOException

public class IOExceptionExample {
    public static void main(String[] args) {
        try {
            File file = new File("nonexistentfile.txt");
            FileInputStream fis = new FileInputStream(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
