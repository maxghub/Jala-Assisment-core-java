package com.jala.access;


//1. Create a class with PRIVATE fields, private method and a main method. Print the fields
//        in main method. Call the private method in main method.
//
//        Create a sub class and try to access the private fields and methods from sub class.
//

public class AccessPrivate {

    private int x=4;
    private void m1(){
        System.out.println("The is private method "+" ,"+"The value of x is : "+x);
    }
    public static void main(String[] args) {


        //Call the private method in main method.
        AccessPrivate p=new AccessPrivate();
        p.m1();


        //access the private fields and methods from sub class.


        //Note
        //A subclass does not inherit the private members of its parent class


    }

     class Child extends AccessPrivate{
        void m2(){
            System.out.println("sub class");
        }
    }
}
