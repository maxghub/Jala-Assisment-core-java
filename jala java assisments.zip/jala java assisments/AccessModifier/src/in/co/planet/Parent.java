package in.co.planet;

import com.jala.ChildAccessPublic;


//out side package

public class Parent {
    public static void main(String[] args) {

        ChildAccessPublic c=new ChildAccessPublic();
        c.m1();
        System.out.println(c.x);
    }
}
