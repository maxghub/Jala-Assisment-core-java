package com.jala.arrays;


//8. Write a function to find the minimum and maximum value of an array

public class MinMaxEle {
    static void minMax(int[] arr){

        int min=arr.length-1;
        int max=0;
        for (int i=0;i<arr.length;i++){

            //Find Max Elmenet
           if(arr[i]>max){
               max=arr[i];
           }

           //Min element find
           if(min>arr[i]){
               min=arr[i];
           }
        }
        System.out.println("Max Element is :"+max);
        System.out.println("Min Element is :"+min);
    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        minMax(arr);

    }
}
