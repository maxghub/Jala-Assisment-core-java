package com.jala;


// Write a program to print the odd and even numbers.

public class OddEven {

    public static void main(String[] args) {

        int n=20;
        System.out.println("Even number between 1 to 20 : ");
        for (int i=1;i<=n;i++){
            if(i%2==0){
                System.out.print(i+" ");
            }
        }
        System.out.println();
        System.out.println("---------------------------------------");
        System.out.println("odd number between 1 to 20 : ");
        for (int i=1;i<=n;i++){
            if(i%2!=0){
                System.out.print(i+" ");
            }
        }

    }
}
