package com.jala.arrays;


//18. Write a program to remove the duplicate elements and return the new array


public class RemoveDuplicateELementNewArray {
    static void removeDupl(int[] arr) {
        int count = 0;

        for (int i = 0; i < arr.length; i++) {
            int x=0;
            for (int j = i+1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    x=1;
                    break;
                }
            }
            if(x==0){
                count++;
            }
        }
        int[] arr1=new int[count];
        int temp=0;
        for (int i = 0; i < arr.length; i++) {
            int x=0;
            for (int j = i+1; j < arr.length; j++) {
                if (arr[i] == arr[j]) {
                    x=1;
                    break;
                }
            }
            if(x==0){
               arr1[temp++]=arr[i];
            }
        }
        for (int ele:arr1){
            System.out.println(ele);
        }
    }

    public static void main(String[] args) {
        int[] arr={1,4,5,3,4,6};
        removeDupl(arr);
    }
}
