package com.jala;


//5. Write a program to print largest number among three numbers.

public class LargestAmongThreeNumber {

    public static void main(String[] args) {

        int a=10,b=12,c=8;
        if(a>b && a>c){
            System.out.println("a is largest number ");
        }
        else if(b>a && b>c ){
            System.out.println("b is largest number");
        }
        else {
            System.out.println("c is largest number");
        }
    }
}
