package com.jala.abstractmodifier;


//2. Create a sub class for an abstract class. Create an object in the child class for the
//abstract class and access the non-abstract methods


abstract class parentAbstract {

    abstract void m1();  // abstract method

    //non abstract method

    void m2() {
        System.out.println("Not abstract method");
    }
}
public class ChildAccessNonabstractMethod extends parentAbstract {

    void m1(){
        System.out.println("this method is available to the parent abstract class");
    }

    public static void main(String[] args) {

        ChildAccessNonabstractMethod c=new ChildAccessNonabstractMethod();
        c.m1();
        c.m2();


        //3. Create an instance for the child class in child class and call abstract methods
        ChildAccessNonabstractMethod c1=new ChildAccessNonabstractMethod();
        c.m1();


        //4. Create an instance for the child class in child class and call non-abstract methods
        ChildAccessNonabstractMethod c2=new ChildAccessNonabstractMethod();
        c2.m2();


    }


}
