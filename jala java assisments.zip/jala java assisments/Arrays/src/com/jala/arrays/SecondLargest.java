package com.jala.arrays;

//13. Write a method to find the second largest number in an array


import java.lang.reflect.Array;
import java.util.Arrays;

public class SecondLargest {
    public static void main(String[] args) {
        int[] arr={2,5,4,7,9,10};
        int n=arr.length;
        Arrays.sort(arr);
        System.out.println(arr[n-2]);
    }
}
