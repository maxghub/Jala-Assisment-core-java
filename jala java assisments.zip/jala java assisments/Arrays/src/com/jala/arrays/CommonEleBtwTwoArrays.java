    package com.jala.arrays;


    //11. Write a program to find the common values between two arrays

    public class CommonEleBtwTwoArrays {
        static void commonEle(int[] arr,int [] arr1){
            for (int i=0;i<arr.length;i++){
                for (int j=0;j<arr1.length;j++){
                    if(arr[i]==arr1[j]){
                        System.out.print(arr1[j]+" ");
                    }
                }
            }
        }
        public static void main(String[] args) {
            int[] arr={1,2,3};
            int[] arr1={2,4,3};
            commonEle(arr,arr1);
        }
    }
