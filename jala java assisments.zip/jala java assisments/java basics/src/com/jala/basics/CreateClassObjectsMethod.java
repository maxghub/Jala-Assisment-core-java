package com.jala.basics;

//1. How to create a class, object, method and its signature

public class CreateClassObjectsMethod {        // here "CreateClassObjectsMethod " is class

    void methodm1(){            // Here "methodm1()" is method with void return type
        System.out.println("this method block");
    }

    public static void main(String[] args) {
        //creating the object CreateClassObjectsMethod of this class
        CreateClassObjectsMethod s=new CreateClassObjectsMethod();
        s.methodm1();  //calling the method
    }
}
