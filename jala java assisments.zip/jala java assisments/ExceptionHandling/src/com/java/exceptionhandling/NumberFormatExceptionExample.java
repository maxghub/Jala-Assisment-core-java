package com.java.exceptionhandling;


//16. Write a program to generate NumberFormatException


public class NumberFormatExceptionExample {
    public static void main(String[] args) {
        String str = "abc";
        try {
            int num = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
}
