package com.java.exceptionhandling;


//8. Write a program to generate Arithmetic Exception

public class GenerateAirthmatic {
    public static void main(String[] args) {
        System.out.println(10/0);
    }
}
