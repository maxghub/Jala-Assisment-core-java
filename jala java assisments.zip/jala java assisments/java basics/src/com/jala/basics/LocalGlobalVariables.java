package com.jala.basics;

//5. Define the local and Global variables with the same name and print both variables and
//        understand the scope of the variables


public class LocalGlobalVariables {
    int x=18;       // Instance varaible
    void localVariable(){
        int x=38; // This is local variable
        System.out.println("This is local variable :"+x);
    }

    public static void main(String[] args) {

     LocalGlobalVariables l=new LocalGlobalVariables();
        System.out.println("Instance variable :"+l.x);

        l.localVariable();   // calling method
    }
}
