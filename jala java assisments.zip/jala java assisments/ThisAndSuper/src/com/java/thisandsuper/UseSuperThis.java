package com.java.thisandsuper;


//6.Use this() and super() in methods not in constructor

public class UseSuperThis {
    void m1() {
        String name = "kaifi";
        System.out.println("m1 method from parent class " +name);

    }

}
class Child12 extends UseSuperThis{
    void m2(){
        super.m1();
        System.out.println("m2 method from child class");
    }
    void m4(){
        this.m2();
        System.out.println("m4 method from child class");

    }
    public static void main(String[] args) {
        Child12 c=new Child12();
        c.m4();
    }
}
