package com.jala.arrays;


//4. Write a function to test if array contains a specific value


public class SpecificeElements {
    static void index_array(int[] arr,int x){
        int temp=1;
        for(int i=0;i<arr.length;i++){
            if(arr[i]==x){
                temp=0;
                break;

            }
            else {
                temp=1;
            }
        }
        if(temp==0){
            System.out.println("yes array contains this element");
        }
        else {
            System.out.println("array does not contain this element");
        }

    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        index_array(arr,4);

    }
}
