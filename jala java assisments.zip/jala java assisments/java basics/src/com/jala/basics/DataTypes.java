package com.jala.basics;

//4. Define variables for different Data Types int, Boolean, char, float, double and print on the
//        Console

public class DataTypes {

    public static void main(String[] args) {
        int a=10 ;   // this is Integer data type
        char c='k';   // This is Character data type
        boolean b=true;  //this is boolean data type we can here only true or false
        float f=1.4f;  // this is float data type
        double d=11.4231;  // this is double data type

        System.out.println("Integer data type value of a is :"+a);
        System.out.println("character data type value of c is :"+c);
        System.out.println("boolean data type value of b is :"+b);
        System.out.println("float data type value of f is :"+f);
        System.out.println("double data type value of d is :"+d);

    }
}
