package com.jala;


//9. Write a program to find the prime or not.

import java.util.Scanner;

public class PrimeOrNot {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any number to check wether it is prime or not :");
        int n=sc.nextInt();

        int x=0;
        for (int i=2;i<=n-1;i++){

            if(n%i==0){
                x=1;
            }
        }
        if(x==1){
            System.out.println(n+" is not prime number");
        }
        else {
            System.out.println(n+" is prime number");
        }
    }
}
