package com.jala;


//10. Write a program to palindrome or not.

import java.util.Scanner;

public class Palindrome {

    public static void main(String[] args) {

        Scanner sc=new Scanner(System.in);
        System.out.println("Enter any number: ");
        int n=sc.nextInt();

        int n1=n;
        int rev=0;
        while (n1>0){
            int temp=n1%10;
            rev=rev*10+temp;
            n1=n1/10;
        }
        if(rev==n){
            System.out.println(n+" Number is palindrome");
        }else {
            System.out.println(n+" The number is not palindrome");
        }
    }
}
