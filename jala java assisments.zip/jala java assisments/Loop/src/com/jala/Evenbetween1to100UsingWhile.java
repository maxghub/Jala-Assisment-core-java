package com.jala;



//6. Write a program to print even number between 10 and 100 using while

public class Evenbetween1to100UsingWhile {
    public static void main(String[] args) {

        int a=1,b=100;

        System.out.println("Even number between 1 to 20 : ");
       while(a<=b){
            if(a%2==0){
                System.out.print(a+" ");
            }
            a++;
        }

    }
}
