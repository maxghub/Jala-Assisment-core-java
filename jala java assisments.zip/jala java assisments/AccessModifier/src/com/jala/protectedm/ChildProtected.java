package com.jala.protectedm;

import com.jala.access.ProtectedModifier;

public class ChildProtected extends ProtectedModifier {
    public static void main(String[] args) {
        ChildProtected p1=new ChildProtected();
        p1.m1();
        System.out.println(p1.x);

    }
}
