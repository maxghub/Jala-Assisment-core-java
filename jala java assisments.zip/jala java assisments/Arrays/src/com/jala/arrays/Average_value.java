package com.jala.arrays;


//2. Write a function to calculate the average value of an array of integers


public class Average_value {
    static int average(int[] arr){
        int n=arr.length;
        int sum=0;
        for (int e:arr){
            sum=sum+e;

        }
        return sum/n;
    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        int result=average(arr);
        System.out.println(result);
    }
}
