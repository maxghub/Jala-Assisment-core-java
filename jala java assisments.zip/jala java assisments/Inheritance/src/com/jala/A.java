package com.jala;

/*
A, B and C are classes
        A is a super class. B is a sub class of A. C is a sub class of B.

        Create three methods in each class, 2 methods are specific to each class and third
        method (override method) should be in all three Classes A, B and C

        Create a class with main method. Create an object for each class A, B and C in main
        method and call every method of each class using its own object/instance.

        Call an overridden method with super class reference to B and C class’s objects

        Runtime Polymorphism with Data Members/Instance variables, Repeat the above
        process only for data members */




//Super class
public class A {
    void m1(){
        System.out.println("Super class A of method m1");

    }
    void m2(){
        System.out.println("Super class A of method m2");

    }
    void m3(){
        System.out.println("Super class A of method m3");
    }
}


//sub class of A
class  B extends A {
    void a1(){
        System.out.println("Sub class B of method a1");
    }
    void a2(){
        System.out.println("Sub class B of method a2");


    }
    void m3(){
        System.out.println("Sub class B of method m3");
    }
}

//sub class of B
class C extends B{
    void c1(){
        System.out.println("Sub class C of method c1");

    }
    void c2(){
        System.out.println("Sub class C of method c2");

    }
    void m3(){
        System.out.println("Sub class C of method c1");

    }

    public static void main(String[] args) {

        A a=new A();
        a.m1();
        a.m2();
        a.m3();

        B b=new B();
        b.a1();
        b.a2();
        b.m1();
        b.m2();
        b.m3();

        C c=new C();
        c.c1();
        c.c2();

        c.m1();
        c.m2();

        c.a1();
        c.a2();

        c.m3();



    }
}
