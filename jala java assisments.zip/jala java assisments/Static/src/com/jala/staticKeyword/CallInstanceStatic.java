package com.jala.staticKeyword;


//4. Call instance methods in static methods

public class CallInstanceStatic {

     void m1(){
         System.out.println("instance method");
//         CallInstanceStatic c=new CallInstanceStatic();
//         c.m2();

    }
    static void m2(){
        System.out.println("static method");
        CallInstanceStatic c=new CallInstanceStatic();
        c.m1();

    }
    public static void main(String[] args) {
           CallInstanceStatic c1=new CallInstanceStatic();
           c1.m2();
    }
}
