package com.jala.interfaceimpl;


//4. Create two interfaces with one method each. Implement these two interfaces in one
//        Class.





//5. Create two interfaces with the same method (same signature) in both the interfaces.
//        Implement these two interfaces in one class. Call the method.


interface Parent4{
    void m4();
    void m1();
}
public interface Parent2 {
    void m1();

}
class Child2 implements Parent2,Parent4{

    @Override
    public void m4() {
        System.out.println("Parent4 class method");
    }

    @Override
    public void m1() {
        System.out.println("Parent2 class method");

    }

    public static void main(String[] args) {
       Child2 c=new Child2();
       c.m1();
    }


}
