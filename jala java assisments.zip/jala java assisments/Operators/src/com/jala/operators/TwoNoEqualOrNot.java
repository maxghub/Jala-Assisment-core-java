package com.jala.operators;

//4. Write a program to find the two numbers equal or not.


public class TwoNoEqualOrNot {
    public static void main(String[] args) {
        int a=10;
        int b=20;

        if(a == b)
        {
            System.out.println("a is equal to b");
        }
        else if(a!=b){
            System.out.println("a is not equal to b");
        }
        else {
            System.out.println("some thing went wrong");
        }
    }
}
