package com.jala.operators;

//2. Write a method for increment and decrement operators(++, --)

public class IncrementAndDecrementOperator {

    //Method for pre increment operator
    static void preIncrement(){
        int a=20;
        int b=++a;
        System.out.println("The value of b is in after preIncrement of a : "+b);
    }

    //Method for postIncrement operator
    static void postIncrement(){
        int a=20;
        int b=a++;
        System.out.println("The value of b is in after postIncrement of a : "+b);
    }

    //Method for postDecrement operator
    static void postDecrement(){
        int a=20;
        int b=a--;
        System.out.println("The value of b is in after postDecrement of a : "+b);
    }

    //Method for preDecrement operator
    static void preDecrement(){
        int a=20;
        int b=--a;
        System.out.println("The value of b is in after preDecrement of a : "+b);
    }
    public static void main(String[] args) {
       IncrementAndDecrementOperator.preIncrement();
       IncrementAndDecrementOperator.postIncrement();
       IncrementAndDecrementOperator.postDecrement();
       IncrementAndDecrementOperator.preDecrement();

    }
}
