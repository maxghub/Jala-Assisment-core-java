package com.jala.abstractmodifier;


//1. Create an abstract class with abstract and non-abstract methods.

abstract class FirstClass {

    abstract void m1();  // abstract method

    //non abstract method

    void m2(){
        System.out.println("Not abstract method");
    }

    public static void main(String[] args) {

    }

}
