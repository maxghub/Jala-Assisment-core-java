package com.java.exceptionhandling;

import java.lang.reflect.Field;
//13. Write a program to generate NoSuchFieldException

public class NoSuchFieldExceptionExample {
    public static void main(String[] args) {
        try {
            Class<?> cls = String.class;
            Field field = cls.getDeclaredField("nonExistentField");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }
}