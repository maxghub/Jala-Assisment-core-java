package com.jala.access;


//2. Create a class with DEFAULT fields and methods. Access these fields and methods
//        from any other class in the same package


 class Child {
    int x = 1;

    void m1() {
        System.out.println("hello");
    }

}
public class DefaultClass {


    public static void main(String[] args) {
        Child c=new Child();
        System.out.println(c.x);
       c.m1();

    }
}
