package com.jala.arrays;


//6. Write a function to copy an array to another array

public class CopyArray {
    static void newArrayELe(int[] arr){
        int[] newArr=new int[arr.length];
        int x=0;
        for (int i=0;i<arr.length;i++){
            newArr[x++]=arr[i];

        }
        System.out.println("New array element is: ");
        for (int ele:newArr){
            System.out.print(ele+" ");
        }

    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        newArrayELe(arr);

    }
}
