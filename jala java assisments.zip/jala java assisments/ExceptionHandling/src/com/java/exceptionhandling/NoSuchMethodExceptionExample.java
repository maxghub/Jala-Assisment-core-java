package com.java.exceptionhandling;


//14. Write a program to generate NoSuchMethodException

import java.lang.reflect.Method;

public class NoSuchMethodExceptionExample {
    public static void main(String[] args) {
        try {
            Class<?> cls = String.class;
            Method method = cls.getDeclaredMethod("nonExistentMethod");
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }
}

