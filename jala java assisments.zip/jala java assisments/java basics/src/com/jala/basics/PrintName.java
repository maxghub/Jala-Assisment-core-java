package com.jala.basics;

//2. Write a program to print your name.

public class PrintName {
    public static void main(String[] args) {
        String name="Mustafiz Kaifi";
        System.out.println("My name is :"+name);      // pring here my name
    }
}
