package com.java.thisandsuper;


/*
2. Print the fields/instance members of the parent class using super
5. Call constructor of the parent class using super()

 */

public class Parent {
    String nm = "Mustafiz Kaifi";

    Parent() {

        System.out.println("This is parent class default constructor!");
    }

}
class Child extends Parent{
    String nm="kaif";

    Child(){
        super();
        System.out.println("This is child class default constructor");
    }
    void child1(){
        System.out.println(super.nm);
    }
    public static void main(String[] args) {

    }
}
