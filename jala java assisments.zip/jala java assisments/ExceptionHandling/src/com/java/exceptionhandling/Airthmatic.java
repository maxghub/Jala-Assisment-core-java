package com.java.exceptionhandling;


//1. Write a program to generate Arithmetic Exception without exception handling



//2. Handle the Arithmetic exception using try-catch block

//7. Write a program with finally block


public class Airthmatic {

    public static void main(String[] args) {
        System.out.println("start");
        try {
            System.out.println("try start");
            int x = 10 / 0;
            System.out.println("try close");
        }
        catch (ArithmeticException e){
            System.out.println(10/2);
        }
        finally {
            System.out.println("it will always excute when try block in available");
        }
        System.out.println("End");
    }
}
