package com.jala.operators;

//1. Write a function for arithmetic operators(+,-,*,/)
public class ArithmeticOperator {
    public static void main(String[] args) {
        int a=8;
        int b=2;
        int x=a+b;
        int y=a-b;
        int z=a*b;
        int t=a/b;
        System.out.println("+ operator :"+ x);
        System.out.println("- operator :"+ y);
        System.out.println("* operator :"+ z);
        System.out.println("/ operator :"+ t);
    }
}
