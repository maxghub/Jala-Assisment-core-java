package com.java.exceptionhandling;


//4. Write a program with multiple catch blocks


public class MultipleCatchBlock {
    public static void main(String[] args) {

        try{
            System.out.println(10/0);
        }
        catch (ArithmeticException e){
            System.out.println("aiths");
        }
        catch (NullPointerException e1){
            System.out.println("null");
        }
    }
}
