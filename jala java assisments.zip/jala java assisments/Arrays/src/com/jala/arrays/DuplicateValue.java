package com.jala.arrays;


//10. Write a function to find the duplicate values of an array


public class DuplicateValue {
    static void dupliateValue(int[] arr,int n){
        int t=0;
        for (int i=0;i<n-1;i++){
            int x=0;
            for (int j=0;j<n;j++){
                if(i==j)
                    continue;
                if(arr[i]==arr[j]){
                    System.out.println(arr[i]);
                }
            }
        }

    }
    public static void main(String[] args) {
        int[] arr={4,2,4,5,6};
        int n=arr.length;
        dupliateValue(arr,n);
    }
}
