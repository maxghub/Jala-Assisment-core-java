package com.jala.basics;


//6. Write a function to print your name and call the function from main method
public class PrintNameAndCallFromMainMethod {

    void myName(String s){
        System.out.println("Your name is : "+s);
    }

    public static void main(String[] args) {
        PrintNameAndCallFromMainMethod p=new PrintNameAndCallFromMainMethod();
        p.myName("Mustafiz Kaifi");
    }
}
