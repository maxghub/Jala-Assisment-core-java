package com.java.thisandsuper;


//1. Print the fields/instance members of the current class using this and without using object
//3. Call constructor of the current class using this()
//4. Call argument constructor of current class using this()


public class First {

    int x;
    int y;

    First(){
        this(8,20);
    }
    First(int x,int y){
        this.x=x;
        this.y=y;
        System.out.println(x+" "+y);
    }
    public static void main(String[] args) {

        First f=new First();
        First f1=new First(2,4);
    }
}
