package com.java.methodoverloading;


//1. Write two methods with the same name but different number of parameters of same type and
// call the methods from main method


//2. Write two methods with the same name but different number of parameters of different
//        data type and call the methods from main method






//3. Write two methods with the same name and same number of parameters of same type
//        and call from main method
//
//        4. Write two methods with the same name and same number of parameters of different
//        type and call from main method
//
//        5. Write two methods with the same name, number of parameters and data type but
//        different return Type


public class Parent1 {

    //1. Write two methods with the same name but different number of parameters of same type and
// call the methods from main method
    void m1(int x){
        System.out.println("1- arg method");
    }
    void m1(int x,int y){
        System.out.println("1-arg method");
    }




    //2. Write two methods with the same name but different number of parameters of different
//        data type and call the methods from main method

    void m2(int x,String name){
        System.out.println("2-arg but different method");
    }
    void m2(int x){
        System.out.println("1-arg but different method");
    }

    //        4. Write two methods with the same name and same number of parameters of different
//        type and call from main method
    void m4(int rollNo) {

        System.out.println("4.Roll number : " + rollNo);
    }
    //same method name different parameter type
    void m4(String name) {
        System.out.println("4.Name : " + name);
    }
    public static void main(String[] args) {


        //1

        Parent1 p=new Parent1();
        p.m1(1);
        p.m1(2,4);

        //2
        p.m2(2);
        p.m2(2,"ksjs");


        //4
        p.m4("kajds");
        p.m4(12);

    }
}
