package com.jala.operators;


//5. Programs on Logical AND,OR operator and Logical NOT

public class Logical {
    public static void main(String[] args) {
        int a = 8;
        int b = 5;
        int c = 4;


        // Logical AND (&&)

        System.out.println(a > b && a > c); //true
        System.out.println(a < b && a < c); //false
        System.out.println(a > b && a < c); //false

        //Logical OR (||)

        System.out.println(a > b || a > c); //true
        System.out.println(a < b || a < c); //false
        System.out.println(a < b || a > c); //true

        //Logical NOT [!()]
        System.out.println(!(a > b));      //false
        System.out.println(!(a < b));      //true
    }
}
