package com.jala;


//7. Write a program to print 1 to 10 using the do-while loop statement.

public class DoWhileLoop {

    public static void main(String[] args) {

        int a=1;
        int b=10;
        do {
            System.out.println(a);
            a++;
        }while (b>=a);
    }
}
