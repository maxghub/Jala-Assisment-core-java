package com.jala.arrays;


//1. Write a function to add integer values of an array

public class Sum_array {
    static int sum(int[] arr){
        int n=arr.length;
        int sum=0;
        for (int e:arr){
            sum=sum+e;

        }
        return sum;
    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        int result=sum(arr);
        System.out.println(result);
    }
}
