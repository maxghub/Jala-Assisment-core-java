package com.jala;


//11. Program to check whether a number is EVEN or ODD using switch

import java.util.Scanner;

public class switchCase {
    public static void main(String[] args) {

       Scanner s=new Scanner(System.in);
       int n=s.nextInt();
        switch (n%2){
            case 0:
                System.out.println("number is even");
                break;
            case 1 :
                System.out.println("Number is odd");
                break;
        }
    }
}
