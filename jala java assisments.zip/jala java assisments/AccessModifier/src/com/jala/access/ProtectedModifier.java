package com.jala.access;


//3. Create a class with PROTECTED fields and methods. Access these fields and methods
//        from any other class in the same package.
//
//        Also, Access the PROTECTED fields and methods from child class located in a different
//        Package
//
//        Access the PROTECTED fields and methods from any class in different package




//Create a class with PROTECTED fields and methods. Access these fields and methods
//        from any other class in the same package.


public class ProtectedModifier {
    protected int x=1;
    protected void m1(){
        System.out.println("protected modifier");
    }
}
class ProtectedCall{


    public static void main(String[] args) {
        ProtectedModifier p=new ProtectedModifier();
        System.out.println(p.x);
        p.m1();



       // Access the PROTECTED fields and methods from any class in different package
//        Note: it is not possible because if we want access protected modifier outside of
//          the package then we can call it by the child class refrence variable on

    }
}
