package com.jala.arrays;


//17. Write a method to verify if the array contains two specified elements(12,23)


public class ContainsEle {
    public static void main(String[] args) {
        int[] arr={1,12,10,15};
        int x=12,y=23;
        int n=arr.length;
        int count=0,count1=0;
        for (int i=0;i<n;i++){
            if(arr[i]==x){
                count=1;
            }
           if (arr[i]==y){
              count1=1;
           }
        }
        if(count==1){
            System.out.println("12 is available on this array");
        }
        else{
            System.out.println("12 is not available on this array");
        }
        if(count1==1){
            System.out.println("23 is present on this array");
        }
        else{
            System.out.println("23 is not available on this array");
        }

    }
}
