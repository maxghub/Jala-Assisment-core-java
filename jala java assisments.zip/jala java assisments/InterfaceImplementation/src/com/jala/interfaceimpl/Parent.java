package com.jala.interfaceimpl;


//1. Create an interface with only one method and implement it in a class. Call the method
//        Implemented.


//8. Create a PUBLIC interface with fields and methods, fields should have values assigned.
//        Implement this interface to some class and print the values of the interface fields and
//        call the interface methods


public interface Parent {

    int x=1;
    static int y=4;
   public abstract void m1();

}
 class Child implements Parent{
     @Override
     public void m1() {
         System.out.println("This is parent class method");
     }
    public static void main(String[] args) {
        Child c=new Child();
        c.m1();
        System.out.println(c.x);
    }


 }
