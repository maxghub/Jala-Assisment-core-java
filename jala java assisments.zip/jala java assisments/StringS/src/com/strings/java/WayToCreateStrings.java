package com.strings.java;


//1. Different ways creating a string

import java.util.Arrays;

public class WayToCreateStrings {
    public static void main(String[] args) {
        String s=new String("First Way");
        String s1="Second way";


        //2. Concatenating two strings using + operator

        String s2="Hello";
        String s4="world";
        System.out.println(s2+s4);



        //3. Finding the length of the string
        System.out.println(s2.length());




        //4. Extract a string using Substring
        String s6="Hello World";
        System.out.println(s2.substring(2));



        //5. Searching in strings using indexOf()
        String s8="Mustafiz Kaifi";
        System.out.println(s8.indexOf('u'));



        //6. Matching a String Against a Regular Expression With matches()

        String m = "here we match the String";
        boolean match = m.matches("(.*)String(.*)");
        System.out.println("Matches : " + match);



        //7. Comparing strings using the methods equals(),

        String sr="Hello";
        String sr2="Hello";
        if(sr.equals(sr2)){
            System.out.println("Matched");
        }
        else {
            System.out.println("Not Match");
        }




        //8. equalsIgnoreCase(), startsWith(), endsWith() and compareTo()

        String a="World";
        String a1="worlD";

        //equalsIgnoreCase()
        if(a.equalsIgnoreCase(a1)){
            System.out.println("Matched");
        }
        else {
            System.out.println("Not Matched");
        }


        //startsWith()
        boolean b=a.startsWith("Wor");
        System.out.println(b);


        //endsWith()
        boolean b1=a.endsWith("ld");
        System.out.println(b1);



        //compareTo()
        System.out.println(a.compareTo(a1));



        //9. Trimming strings with trim()

        String c="  Mustafiz Kaifi    ";
        System.out.println(c.trim());



        //10. Replacing characters in strings with replace()

        String d="HelloI";

        System.out.println(d.replace('I','!'));




        //11. Splitting strings with split()

        String[] ss= ("Mustafiz Kaifi".split(" "));
        for (String i:ss){
            System.out.println(i);
        }



        //12. Converting Numbers to Strings with valueOf()
        int x1=12;
        String nt=String.valueOf(x1);
        System.out.println(nt);




        //13. Converting integer objects to Strings

        int x=124534;
        String st=Integer.toString(x);
        System.out.println(st);




        //14. Converting to uppercase and lowercase
        String up="HELLO WORLD";
        System.out.println(up.toLowerCase());


    }
}
