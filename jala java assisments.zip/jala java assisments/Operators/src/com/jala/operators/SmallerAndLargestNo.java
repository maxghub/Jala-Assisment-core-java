package com.jala.operators;


//7. Print the smaller and larger number

public class SmallerAndLargestNo {
    public static void main(String[] args) {
        int a=2;
        int b=1;

        if(a>b){
            System.out.println("a is the larger number");
        } else if (b<a) {
            System.out.println("b is the smaller number");

        }
    }
}
