package com.jala.basics;


//3. Write a program for a Single line comment, multi-line and documentation comments
public class Comments {

    public static void main(String[] args) {
         // single line comment
            //int a=10;         // this is single line comment


        /* multi line comment */

        /* System.out.println("hello");
        System.out.println("multi line comment"); */         // this is multi line comment



        /** Documentation comment */

        /** System.out.println("Documentation comment "); */   //this is documentation comment

    }
}
