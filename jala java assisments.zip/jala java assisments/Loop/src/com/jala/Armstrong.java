package com.jala;


//8. Write a program to find Armstrong number or not

import java.util.Scanner;

public class Armstrong {
    static boolean isArmstrong(int n) {
        int r, result = 0;
        int temp = n;
        while (n != 0) {
            r = n % 10;
            result += (r * r * r);
            n = n / 10;
        }
        return temp == result;
    }

    public static void main(String[] args) {
        System.out.print("Enter a number : ");

        int n = new Scanner(System.in).nextInt();
        if (isArmstrong(n)) {
            System.out.println(n + " is an Armstrong number");
        } else {
            System.out.println(n + " is not an Armstrong number");
        }

    }
}
