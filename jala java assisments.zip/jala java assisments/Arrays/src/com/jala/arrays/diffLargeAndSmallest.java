package com.jala.arrays;


//16. Write a function to get the difference of largest and smallest value

public class diffLargeAndSmallest {
    static int minMax(int[] arr){

        int min=arr.length-1;
        int max=0;
        for (int i=0;i<arr.length;i++){

            //Find Max Elmenet
            if(arr[i]>max){
                max=arr[i];
            }

            //Min element find
            if(min>arr[i]){
                min=arr[i];
            }
        }
        return max-min;

    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
       int result= minMax(arr);
        System.out.println(result);

    }
}
