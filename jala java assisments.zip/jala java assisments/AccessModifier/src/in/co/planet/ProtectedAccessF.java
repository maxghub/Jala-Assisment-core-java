package in.co.planet;

public class ProtectedAccessF {
    public static void main(String[] args) {

    }
}
