package com.jala.staticKeyword;


//1. Write a class with 2 static variables, 2 Instance variables, 2 static methods, 2 instance
//        methods and a main method.


public class staticInstance {


    //2 static variables   ---------> here x and y is static variable
    static int x=1;
    static int y=2;

    //2 instance variables   ---------> here x and y is instance variable
    int p=4;
    int k=6;

    static void m1(){
        System.out.println("m1 static method");
    }
    static void m2(){
        System.out.println("m2 static method");
    }

    void m4(){
        System.out.println("m4 instance method");
    }

    void m5(){
        System.out.println("m5 instance method");
    }

    public static void main(String[] args) {

    }
}
