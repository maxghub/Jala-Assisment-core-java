package com.jala.operators;


//6. Program for relational operators (<,<==, >, >==)


public class RelationalOperator {
    public static void main(String[] args) {

        int a = 35;
        int b = 45;
        System.out.println(a < b);  //less than ( < )
        System.out.println(a > b);  //greater than ( > )
        System.out.println(a <= b); //less than or equals( <= )
        System.out.println(a >= b); //greater than or equals( >= )
    }
}
