package com.java.exceptionhandling;


//17. Write a program to generate StringIndexOutOfBoundsException


public class StringIndexOutOfBoundsExceptionExample {
    public static void main(String[] args) {
        String str = "Hello";
        try {
            char ch = str.charAt(10);
        } catch (StringIndexOutOfBoundsException e) {
            e.printStackTrace();
        }
    }
}
