package com.java.exceptionhandling;


//10. Write a program to generate ClassNotFoundException


public class ClassNotFOund {
    public static void main(String[] args) {
        try {
            Class.forName("com.java.exceptionhandling");
            ClassLoader.getSystemClassLoader().loadClass("com.java.exceptionhandling");

        } catch (ClassNotFoundException e) {

            e.printStackTrace();
        }
    }
}
