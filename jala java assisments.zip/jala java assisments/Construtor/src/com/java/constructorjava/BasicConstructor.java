package com.java.constructorjava;


//1. Write a class with a default constructor, one argument constructor and two argument
//        constructors. Instantiate the class to call all the constructors of that class from a main
//        Class



//2. Call the constructors(both default and argument constructors) of super class from a child
//        Class





public class BasicConstructor {
    int x;
    int y;

    BasicConstructor() {
        System.out.println("default parent constructor");
    }

    BasicConstructor(int x) {
        this.x = x;
        System.out.println("1-arg constructor");
    }

    BasicConstructor(int x, int y) {
        this.x = x;
        this.y = y;
        System.out.println("2-arg constructor");
    }




}
//2. Call the constructors(both default and argument constructors) of super class from a child
//Class

    class Basic1Conchild extends BasicConstructor{
        Basic1Conchild(){
           super();
    }
        Basic1Conchild(int x){
            super(2);
    }
        Basic1Conchild(int x,int y){
            super(2,4);
        }
    public static void main(String[] args) {
//        BasicConstructor b=new BasicConstructor();
//        BasicConstructor b1=new BasicConstructor(2);
//        BasicConstructor b2=new BasicConstructor(4,8);


        Basic1Conchild  b=new Basic1Conchild();
        Basic1Conchild  b1=new Basic1Conchild(2);
        Basic1Conchild  b2=new Basic1Conchild(2,4);




    }
}
