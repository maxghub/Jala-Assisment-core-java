package com.jala.staticKeyword;


//3. Print static variables in Instance methods

public class printStatic {
    static int x=1;
     void m1(){
         System.out.println(x);
     }
    public static void main(String[] args) {
       printStatic p=new printStatic();
       p.m1();

    }
}
