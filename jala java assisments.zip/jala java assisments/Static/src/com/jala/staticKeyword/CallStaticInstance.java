package com.jala.staticKeyword;


//5. Call static methods in instance methods

public class CallStaticInstance {
    void m1(){
        System.out.println("instance method");
      m2();

    }
    static void m2(){
        System.out.println("static method");


    }
    public static void main(String[] args) {
        CallInstanceStatic c1=new CallInstanceStatic();
        c1.m1();
        CallInstanceStatic.m2();

    }
}
