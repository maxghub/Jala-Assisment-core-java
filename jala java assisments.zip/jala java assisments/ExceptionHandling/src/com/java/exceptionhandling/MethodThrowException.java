package com.java.exceptionhandling;


//3. Write a method which throws exception, Call that method in main class without try block

public class MethodThrowException {
    static void voidException() {

        throw new RuntimeException("Throwing exception");
    }

    public static void main(String[] args) {
        voidException();
    }
}