package com.jala.arrays;


//15. Write a method to find number of even number and odd numbers in an array

public class OddAndEven {
    public static void main(String[] args) {
        int[] arr={2,4,5,7,9,10};
        int n=arr.length;
        System.out.println("Even number");
        for (int i=0;i<n;i++){
            if(arr[i]%2==0){
                System.out.print(arr[i]+" ");
            }
        }
        System.out.println();
        System.out.println("Odd number");
        for (int i=0;i<n;i++){
            if(arr[i]%2!=0){
                System.out.print(arr[i]+" ");
            }
        }
    }
}
