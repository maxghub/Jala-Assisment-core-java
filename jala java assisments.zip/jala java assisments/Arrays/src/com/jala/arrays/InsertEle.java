package com.jala.arrays;


//7. Write a function to insert an element at a specific position in the array

public class InsertEle {
    static void inserElement(int[] arr){


        for (int i=0;i<arr.length;i++){
             if(i==4){
                 arr[i]=12;
             }

        }
        for (int ele:arr){
            System.out.println(ele);
        }


    }
    public static void main(String[] args) {
        int[] arr={2,4,6,8,10};
        inserElement(arr);

    }
}
