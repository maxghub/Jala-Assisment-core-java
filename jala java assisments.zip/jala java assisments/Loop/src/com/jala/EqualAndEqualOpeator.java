package com.jala;


//3. Program to equal operator and not equal operators

public class EqualAndEqualOpeator {

    public static void main(String[] args) {

        //Equal operator
        int a=10;
        if(a==10){
            System.out.println("the value of a is 10");
        }
        else {
            System.out.println("the value of a is not 10");
        }


        // Not equal operator
        int b=20;
        if(b!=10){
            System.out.println("the value of b is not 10");
        }
        else {
            System.out.println("The value of b is 1");

        }

    }
}
