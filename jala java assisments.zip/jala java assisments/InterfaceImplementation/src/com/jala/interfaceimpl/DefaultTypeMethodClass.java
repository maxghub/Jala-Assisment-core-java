package com.jala.interfaceimpl;


//6. Create an interface with a default method and implement it in a class. Do not provide
//        implementation to the default method and call the method.


public interface DefaultTypeMethodClass {
    default void m2() {
        System.out.println("Default method ");
    }

}
class Childc implements DefaultTypeMethodClass{

    public static void main(String[] args) {
        Childc c=new Childc();
        c.m2();
    }
}
