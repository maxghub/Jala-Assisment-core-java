package com.jala.staticKeyword;


//2. Print instance variables in static methods

public class printInstance {
    int x=1;
    static void m1(){
       printInstance p=new printInstance();
        System.out.println(p.x);
    }
    public static void main(String[] args) {

       printInstance.m1();
    }
}
