// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    void m1() {
        System.out.println("parent class method here");

    }

}
class child extends  Main{
    void m1(){
        System.out.println("child class method here");

    }
    public static void main(String[] args) {
        child c=new child();
        c.m1();
    }
}