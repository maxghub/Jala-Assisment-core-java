package com.jala.interfaceimpl;


//7. Create an interface and inherit it from the other interface.


public interface UseExtendseyword {
    int x = 1;
}
interface Childm extends UseExtendseyword{
    int y=4;
    public static void main(String[] args) {
        
    }
}
