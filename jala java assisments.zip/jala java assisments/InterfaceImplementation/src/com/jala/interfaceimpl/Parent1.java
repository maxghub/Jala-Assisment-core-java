package com.jala.interfaceimpl;


//2. Create an interface with two methods, but implement only one in a class. Call the
//        method implemented.



//3. Use Interface instances to call the implemented method in the implemented class







public interface Parent1 {
    void m1();

    void m2();


}
class Child1 implements Parent1{
    @Override
    public void m1() {
        System.out.println("M1 method");
    }

    @Override
    public void m2() {
        System.out.println("M2 method");
    }

    public static void main(String[] args) {
        Child1 c=new Child1();
        c.m1();
        c.m2();
    }


}
